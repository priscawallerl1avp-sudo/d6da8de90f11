# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(todo-scan src/todo-scan.cpp)
set_property(TARGET todo-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(todo-scan lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(qemu-aarch64 src/qemu-aarch64.cpp)
set_property(TARGET qemu-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-aarch64 lionss pthread)

add_executable(cross-mingw64 src/cross-mingw64.cpp)
set_property(TARGET cross-mingw64 PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-mingw64 lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(cve-check src/cve-check.cpp)
set_property(TARGET cve-check PROPERTY CXX_STANDARD 11)
target_link_libraries(cve-check lionss pthread)

add_executable(rollback-tests src/rollback-tests.cpp)
set_property(TARGET rollback-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(rollback-tests lionss pthread)

add_executable(bloat-check src/bloat-check.cpp)
set_property(TARGET bloat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(bloat-check lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(ios-simulator src/ios-simulator.cpp)
set_property(TARGET ios-simulator PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-simulator lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(sandbox-build src/sandbox-build.cpp)
set_property(TARGET sandbox-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sandbox-build lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(valgrind-drd src/valgrind-drd.cpp)
set_property(TARGET valgrind-drd PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-drd lionss pthread)

add_executable(gitleaks src/gitleaks.cpp)
set_property(TARGET gitleaks PROPERTY CXX_STANDARD 11)
target_link_libraries(gitleaks lionss pthread)

add_executable(smoke-tests src/smoke-tests.cpp)
set_property(TARGET smoke-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke-tests lionss pthread)

