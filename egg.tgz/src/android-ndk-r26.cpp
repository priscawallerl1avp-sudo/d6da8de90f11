// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "android ndk r26");
  std::fflush(stdout);
  return lionss_run_workload("android-ndk-r26");
}
